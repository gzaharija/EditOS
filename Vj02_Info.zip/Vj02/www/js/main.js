window.onload = postavi;

function postavi(){
  document.addEventListener("deviceready", pokreni);
}

function pokreni(){
  document.getElementById("marka").innerHTML = device.manufacturer;
  document.getElementById("model").innerHTML = device.model;
}