window.onload = postavi;
//Funkcija za onload događaj
function postavi(){
  //stranica osluškuje kada je uređaj spreman
  document.addEventListener("deviceready", pokreni);
}
//Funkcija za deviceready događaj
function pokreni(){
  document.getElementById("marka").innerHTML = device.manufacturer;
  document.getElementById("model").innerHTML = device.model;
}