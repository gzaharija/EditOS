window.onload = postavi;
function postavi() {
  document.addEventListener("deviceready", pokreni);
}

function pokreni() {
  document.getElementById("slikaj").addEventListener("click", slikaj);
}

function slikaj() {

  var opcije = { quality: 80 };
  navigator.camera.getPicture(uspjeh, greska, opcije);

}

function uspjeh(podaci) {
  //Dohvaćamo img element
  var element = document.getElementById("foto");
  //Mijenjamo njegov src atribut
  element.src = podaci;
}

function greska(podaci) {
  //Ispisujemo podatke o pogrešci
  alert(podaci);
}